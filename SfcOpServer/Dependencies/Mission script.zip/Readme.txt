Copy or move the mission script to "%clientfolder%/Assets/Scripts"
